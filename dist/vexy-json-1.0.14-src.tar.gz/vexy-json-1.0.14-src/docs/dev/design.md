---
layout: page
title: Design
permalink: /design/
nav_order: 9
has_children: true
---

# Design

This section contains design documents and architectural decisions for the vexy_json project.

## Topics

- [Python API Design](python-api/) - Design for Python bindings using PyO3