#!/bin/bash
# this_file: release.sh
# Simple wrapper that forwards all arguments to scripts/release.sh

exec ./scripts/release.sh "$@"