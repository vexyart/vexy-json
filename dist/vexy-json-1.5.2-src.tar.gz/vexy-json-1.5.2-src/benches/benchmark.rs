// this_file: benches/benchmark.rs

const ITERATIONS: u32 = 100;

struct BenchmarkResult {
    case: String,
    vexy_json_ns: f64,
}
