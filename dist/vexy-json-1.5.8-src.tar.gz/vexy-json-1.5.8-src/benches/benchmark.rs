// this_file: benches/benchmark.rs

#[allow(dead_code)]
const ITERATIONS: u32 = 100;

#[allow(dead_code)]
struct BenchmarkResult {
    case: String,
    vexy_json_ns: f64,
}
