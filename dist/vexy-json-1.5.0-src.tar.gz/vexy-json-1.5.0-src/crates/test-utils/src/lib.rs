// Shared test helpers
